import OpenAI from "openai";

export async function POST(request) {
  try {
    const { prompt } = await request.json();
    if (!prompt) return Response.json({ error: "Prompt is required." }, { status: 400 });
    if (!process.env.OPENAI_API_KEY) return Response.json({ error: "OPENAI_API_KEY is not configured." }, { status: 500 });

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const result = await client.images.generate({
      model: process.env.OPENAI_IMAGE_MODEL || "gpt-image-1",
      prompt,
      size: "1024x1024"
    });
    const b64 = result.data?.[0]?.b64_json;
    if (!b64) throw new Error("No image was returned.");
    return Response.json({ image: `data:image/png;base64,${b64}` });
  } catch (error) {
    console.error(error);
    return Response.json({ error: "Image generation failed." }, { status: 500 });
  }
}