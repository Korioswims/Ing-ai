import OpenAI from "openai";

export async function POST(request) {
  try {
    const { text } = await request.json();
    if (!text) return Response.json({ error: "Text is required." }, { status: 400 });
    if (!process.env.OPENAI_API_KEY) return Response.json({ error: "OPENAI_API_KEY is not configured." }, { status: 500 });

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const audio = await client.audio.speech.create({
      model: process.env.OPENAI_TTS_MODEL || "gpt-4o-mini-tts",
      voice: "alloy",
      input: text.slice(0, 4000),
      response_format: "mp3"
    });
    return new Response(Buffer.from(await audio.arrayBuffer()), {
      headers: { "Content-Type": "audio/mpeg", "Cache-Control": "no-store" }
    });
  } catch (error) {
    console.error(error);
    return Response.json({ error: "Speech generation failed." }, { status: 500 });
  }
}