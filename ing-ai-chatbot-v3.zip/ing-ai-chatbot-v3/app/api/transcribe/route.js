import OpenAI from "openai";

export async function POST(request) {
  try {
    const form = await request.formData();
    const audio = form.get("audio");
    if (!audio) return Response.json({ error: "Audio is required." }, { status: 400 });
    if (!process.env.OPENAI_API_KEY) return Response.json({ error: "OPENAI_API_KEY is not configured." }, { status: 500 });

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const result = await client.audio.transcriptions.create({
      file: audio,
      model: process.env.OPENAI_TRANSCRIBE_MODEL || "gpt-4o-mini-transcribe"
    });
    return Response.json({ text: result.text });
  } catch (error) {
    console.error(error);
    return Response.json({ error: "Voice transcription failed." }, { status: 500 });
  }
}