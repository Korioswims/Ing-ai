import OpenAI from "openai";

export async function POST(request) {
  try {
    const { messages } = await request.json();
    if (!Array.isArray(messages) || !messages.length) return Response.json({ error: "No messages." }, { status: 400 });
    if (!process.env.OPENAI_API_KEY) return Response.json({ error: "OPENAI_API_KEY is not configured." }, { status: 500 });

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const input = messages.slice(-30).filter(m => ["user", "assistant"].includes(m.role))
      .map(m => ({ role: m.role, content: m.content }));

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5",
      instructions: "You are Ing, a friendly general-purpose AI assistant. Answer clearly. Use web search when current, changing, or source-backed information is useful.",
      tools: [{ type: "web_search_preview" }],
      input
    });

    const sources = [];
    for (const item of response.output || []) {
      if (item.type === "web_search_call" && item.action?.sources) {
        for (const s of item.action.sources) sources.push({ title: s.title, url: s.url });
      }
    }
    return Response.json({ message: response.output_text, sources });
  } catch (error) {
    console.error(error);
    return Response.json({ error: "Ing could not answer right now." }, { status: 500 });
  }
}