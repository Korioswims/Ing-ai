"use client";

import { useEffect, useRef, useState } from "react";

const starter = () => ({
  id: crypto.randomUUID(),
  title: "New chat",
  messages: [{ role: "assistant", content: "Hey! I'm Ing. I can chat, search the web, create images, and talk with you." }]
});

export default function Home() {
  const [chats, setChats] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [voice, setVoice] = useState(false);
  const [menu, setMenu] = useState(false);
  const bottom = useRef(null);
  const recorder = useRef(null);
  const chunks = useRef([]);

  useEffect(() => {
    const saved = localStorage.getItem("ing-v3-chats");
    try {
      const parsed = saved ? JSON.parse(saved) : [];
      const list = parsed.length ? parsed : [starter()];
      setChats(list);
      setActiveId(list[0].id);
    } catch {
      const fresh = starter();
      setChats([fresh]);
      setActiveId(fresh.id);
    }
  }, []);

  useEffect(() => {
    if (chats.length) localStorage.setItem("ing-v3-chats", JSON.stringify(chats));
  }, [chats]);

  useEffect(() => bottom.current?.scrollIntoView({ behavior: "smooth" }), [chats, activeId, loading]);

  const active = chats.find(c => c.id === activeId);

  function newChat() {
    const c = starter();
    setChats(x => [c, ...x]);
    setActiveId(c.id);
    setInput("");
  }

  function deleteChat(id) {
    const left = chats.filter(c => c.id !== id);
    const list = left.length ? left : [starter()];
    setChats(list);
    if (id === activeId) setActiveId(list[0].id);
  }

  async function sendMessage(e, override) {
    e?.preventDefault();
    const text = (override ?? input).trim();
    if (!text || loading || !active) return;

    const next = [...active.messages, { role: "user", content: text }];
    setChats(x => x.map(c => c.id === activeId
      ? { ...c, title: c.title === "New chat" ? text.slice(0, 34) : c.title, messages: next }
      : c));
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: next })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Request failed.");
      const assistant = { role: "assistant", content: data.message, sources: data.sources || [] };
      setChats(x => x.map(c => c.id === activeId ? { ...c, messages: [...next, assistant] } : c));
    } catch (err) {
      setChats(x => x.map(c => c.id === activeId
        ? { ...c, messages: [...next, { role: "assistant", content: `Sorry — ${err.message}` }] }
        : c));
    } finally {
      setLoading(false);
    }
  }

  async function generateImage() {
    const prompt = input.trim();
    if (!prompt || loading) return;
    const next = [...active.messages, { role: "user", content: `Create an image: ${prompt}` }];
    setChats(x => x.map(c => c.id === activeId ? { ...c, messages: next } : c));
    setInput("");
    setLoading(true);
    try {
      const res = await fetch("/api/image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Image generation failed.");
      setChats(x => x.map(c => c.id === activeId
        ? { ...c, messages: [...next, { role: "assistant", content: "Here you go.", image: data.image }]}
        : c));
    } catch (err) {
      setChats(x => x.map(c => c.id === activeId
        ? { ...c, messages: [...next, { role: "assistant", content: `Sorry — ${err.message}` }]}
        : c));
    } finally { setLoading(false); }
  }

  async function toggleVoice() {
    if (voice) {
      recorder.current?.stop();
      setVoice(false);
      return;
    }
    if (!navigator.mediaDevices?.getUserMedia) {
      alert("Voice recording is not supported in this browser.");
      return;
    }
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const r = new MediaRecorder(stream);
    chunks.current = [];
    r.ondataavailable = e => chunks.current.push(e.data);
    r.onstop = async () => {
      stream.getTracks().forEach(t => t.stop());
      const blob = new Blob(chunks.current, { type: r.mimeType || "audio/webm" });
      const form = new FormData();
      form.append("audio", blob, "voice.webm");
      try {
        const res = await fetch("/api/transcribe", { method: "POST", body: form });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error);
        setInput(data.text || "");
      } catch (e) { alert(e.message || "Transcription failed."); }
    };
    recorder.current = r;
    r.start();
    setVoice(true);
  }

  async function speak(text) {
    try {
      const res = await fetch("/api/speech", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text })
      });
      if (!res.ok) throw new Error("Speech failed.");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const audio = new Audio(url);
      audio.play();
    } catch (e) { alert(e.message); }
  }

  if (!active) return null;

  return (
    <main className="shell">
      <section className="app">
        <aside className="sidebar">
          <div className="brand"><div className="logo">I</div><b>Ing</b></div>
          <button className="new" onClick={newChat}>＋ New chat</button>
          <div className="chatList">
            {chats.map(c => (
              <div className={`chatItem ${c.id === activeId ? "selected" : ""}`} key={c.id}>
                <button onClick={() => setActiveId(c.id)}>{c.title}</button>
                <button className="x" onClick={() => deleteChat(c.id)}>×</button>
              </div>
            ))}
          </div>
          <div className="sideNote">Local chat history is stored in this browser. Add a database/auth provider for true cloud sync.</div>
        </aside>

        <section className="chat">
          <header className="topbar">
            <div><h1>{active.title}</h1><p>General AI assistant</p></div>
            <button className="mobileNew" onClick={newChat}>＋</button>
          </header>

          <div className="messages">
            {active.messages.map((m, i) => (
              <div className={`row ${m.role}`} key={i}>
                <div className="bubble">
                  {m.content}
                  {m.image && <img className="generated" src={m.image} alt="Generated by Ing" />}
                  {m.sources?.length > 0 && (
                    <div className="sources">
                      {m.sources.map((s, j) => <a key={j} href={s.url} target="_blank" rel="noreferrer">{s.title || s.url}</a>)}
                    </div>
                  )}
                  {m.role === "assistant" && !m.image && <button className="speak" onClick={() => speak(m.content)}>🔊</button>}
                </div>
              </div>
            ))}
            {loading && <div className="row assistant"><div className="bubble typing"><i/><i/><i/></div></div>}
            <div ref={bottom}/>
          </div>

          <form className="composer" onSubmit={sendMessage}>
            <button type="button" className={voice ? "activeTool" : ""} onClick={toggleVoice}>{voice ? "⏹" : "🎤"}</button>
            <input value={input} onChange={e => setInput(e.target.value)} placeholder="Message Ing..." disabled={loading}/>
            <button type="button" onClick={generateImage} disabled={!input.trim() || loading}>🖼️</button>
            <button type="submit" disabled={!input.trim() || loading}>Send</button>
          </form>
          <footer>Ing can make mistakes. Check important information.</footer>
        </section>
      </section>
    </main>
  );
}