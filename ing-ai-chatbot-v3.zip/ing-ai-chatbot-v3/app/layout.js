import "./globals.css";

export const metadata = {
  title: "Ing — AI Assistant",
  description: "Chat, search, create images, and talk with Ing.",
};

export default function RootLayout({ children }) {
  return <html lang="en"><body>{children}</body></html>;
}