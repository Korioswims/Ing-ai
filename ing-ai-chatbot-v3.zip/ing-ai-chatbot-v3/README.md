# Ing v3 — Everything at once

This build combines:
- AI chat with conversation context
- Local multi-chat history
- Web search in the assistant route
- Image generation
- Voice input/transcription
- Text-to-speech replies
- Responsive desktop/mobile UI

## Setup

Requires Node.js 18+.

```bash
npm install
```

Copy `.env.example` to `.env.local` and set:

```env
OPENAI_API_KEY=your_api_key_here
OPENAI_MODEL=gpt-5
OPENAI_IMAGE_MODEL=gpt-image-1
OPENAI_TTS_MODEL=gpt-4o-mini-tts
OPENAI_TRANSCRIBE_MODEL=gpt-4o-mini-transcribe
```

Run:

```bash
npm run dev
```

Then open the local URL from Next.js.

## Important production note

The app currently stores conversations in browser localStorage. That means chats do not yet sync between devices and there is no real account system.

To make the app fully cloud-synced, add:
1. Authentication (for example, an auth provider).
2. A database for users, conversations, and messages.
3. Server-side authorization on every database operation.
4. Rate limiting and usage controls.
5. Secure file/object storage if you add uploads.

The OpenAI API key is kept server-side in API routes.

The web-search, image, transcription, and speech integrations use OpenAI APIs. Check current API/model availability and pricing before production deployment.
